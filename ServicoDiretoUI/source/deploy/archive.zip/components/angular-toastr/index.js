require('./dist/angular-toastr.tpls.js');
module.exports = 'toastr';

