(function (String, angular) {
    'use strict';
