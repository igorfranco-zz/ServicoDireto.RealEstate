require('./build/loading-bar');
module.exports = 'angular-loading-bar';
